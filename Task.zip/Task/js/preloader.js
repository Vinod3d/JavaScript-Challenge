// PRELOADER

(function (){
    window.addEventListener('load', function (){
        var preloadpage = this.document.getElementById("page_loader");
        preloadpage.style.display = "none";
    })
})();